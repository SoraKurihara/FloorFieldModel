from FloorFieldModel.hc.handle_collisions import handle_collisions
