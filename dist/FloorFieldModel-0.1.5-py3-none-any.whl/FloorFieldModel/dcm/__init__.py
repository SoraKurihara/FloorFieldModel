from .distance_calc_method import L1norm, L2norm, Linfnorm
