from FloorFieldModel.cp.calc_probability import p_ij
